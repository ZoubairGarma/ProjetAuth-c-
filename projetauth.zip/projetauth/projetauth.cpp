#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <openssl/sha.h>
#include <regex>

using namespace std;

class Hash {
public:
    static string sha256(const string& input) {
        unsigned char hash[SHA256_DIGEST_LENGTH];
        SHA256((const unsigned char*)input.c_str(), input.size(), hash);

        stringstream ss;
        for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
            ss << hex << (int)hash[i];
        }
        return ss.str();
    }

    static string generate_salt() {
        srand(time(0));
        string salt = "";
        for (int i = 0; i < 16; i++) { // 16-char salt
            salt += (char)('A' + rand() % 26);
        }
        return salt;
    }
};

class User {
public:
    string username;
    string hashed_password;
    string salt;

    User(string u, string hp, string s) : username(u), hashed_password(hp), salt(s) {}

    string user_to_string() const {
        return username + "," + hashed_password + "," + salt;
    }

    static User from_string(const string& line) {
        stringstream ss(line);
        string u, hp, s;
        getline(ss, u, ',');
        getline(ss, hp, ',');
        getline(ss, s, ',');
        return User(u, hp, s);
    }
};

class UserRepository {
private:
    string filename;

public:
    UserRepository(const string& file) : filename(file) {}

    void save_user(const User& user) {
        ofstream file(filename, ios::app);
        if (file.is_open()) {
            file << user.user_to_string() << endl;
            file.close();
        }
    }

    User* find_user(const string& username) {
        ifstream file(filename);
        string line;
        while (getline(file, line)) {
            User user = User::from_string(line);
            if (user.username == username) {
                file.close();
                return new User(user);
            }
        }
        file.close();
        return nullptr;
    }
};

class AuthService {
private:
    UserRepository repo;

public:
    AuthService(const string& file) : repo(file) {}

    bool is_valid_username(const string& username) {
        return username.find(',') == string::npos;  // No commas allowed
    }

    bool is_valid_password(const string& password) {
        // Password must be at least 8 characters and contain at least one lowercase, one uppercase, one digit, and one special character.
        regex password_regex("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*])[A-Za-z\\d!@#$%^&*]{8,}$");
        return regex_match(password, password_regex);
    }

    bool user_exists(const string& username) {
        if (repo.find_user(username)) {
            return true; 
        }
        return false;
    }

    void register_user(const string& username, const string& password) {
        if (!is_valid_username(username)) {
            cout << "Invalid username! Username cannot contain commas.\n";
            return;
        }

        if (!is_valid_password(password)) {
            cout << "Password is too weak! It must be at least 8 characters, contain at least one uppercase letter, one lowercase letter, one digit, and one special character.\n";
            return;
        }

        if (user_exists(username)) {
            cout << "User already exists!" << endl;
            return;
        }

        string salt = Hash::generate_salt();
        string hashed_password = Hash::sha256(password + salt);
        User newUser(username, hashed_password, salt);
        repo.save_user(newUser);
        cout << "User registered successfully!" << endl;
    }

    bool login(const string& username, const string& password) {
        User* user = repo.find_user(username);
        if (!user) {
            cout << "User not found!" << endl;
            return false;
        }

        string hashed_input_password = Hash::sha256(password + user->salt);
        if (hashed_input_password == user->hashed_password) {
            cout << "Login successful!" << endl;
            delete user;
            return true;
        } else {
            cout << "Incorrect password!" << endl;
            delete user;
            return false;
        }
    }
};

int main() {
    AuthService auth("users.csv");
    int choice;
    string username, password;

    while (true) {
        cout << "\n1. Register\n2. Login\n3. Exit\nEnter choice: ";
        cin >> choice;

        if (choice == 1) {
            cout << "Enter username: ";
            cin >> username;
            cout << "Enter password: ";
            cin >> password;
            auth.register_user(username, password);
        } else if (choice == 2) {
            cout << "Enter username: ";
            cin >> username;
            cout << "Enter password: ";
            cin >> password;
            auth.login(username, password);
        } else if (choice == 3) {
            cout << "Exiting...\n";
            break;
        } else {
            cout << "Invalid choice! Try again.\n";
        }
    }

    return 0;
}
